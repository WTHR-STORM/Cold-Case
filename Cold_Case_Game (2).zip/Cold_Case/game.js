'use strict';

(() => {
  const SAVE_KEY = 'coldCaseSave_v1';
  const PAGE_SIZE = 20;
  const CAMPAIGN_LENGTH = 25;
  const PACK_PRICE = 1000;
  const RARITIES = [
    { name: 'Common', weight: 48, color: '#a9c4d4', tier: 0, price: 300 },
    { name: 'Uncommon', weight: 27, color: '#72d5b9', tier: 1, price: 480 },
    { name: 'Rare', weight: 15, color: '#72baff', tier: 2, price: 760 },
    { name: 'Epic', weight: 7, color: '#c29aff', tier: 3, price: 1150 },
    { name: 'Legendary', weight: 2.5, color: '#f4cf83', tier: 4, price: 1850 },
    { name: 'Mythic', weight: 0.5, color: '#ff9fbd', tier: 5, price: 3100 }
  ];
  const ELEMENTS = [
    { name: 'Frost', symbol: '❄', top: '#164d70', sigil: '#b8f0ff', glow: 'rgba(99,217,255,.55)', hue: '#88dff8' },
    { name: 'Flame', symbol: '♨', top: '#653b43', sigil: '#ffc2a2', glow: 'rgba(255,142,109,.48)', hue: '#ffae8c' },
    { name: 'Tide', symbol: '≈', top: '#174c63', sigil: '#8fe8ef', glow: 'rgba(70,206,224,.5)', hue: '#70dbe7' },
    { name: 'Storm', symbol: 'ϟ', top: '#39416d', sigil: '#d4d3ff', glow: 'rgba(151,152,255,.5)', hue: '#aaa9ff' },
    { name: 'Stone', symbol: '⬟', top: '#514d45', sigil: '#e8d3a5', glow: 'rgba(223,192,125,.4)', hue: '#d9bc8b' },
    { name: 'Verdant', symbol: '❧', top: '#255342', sigil: '#a4efbd', glow: 'rgba(114,226,153,.42)', hue: '#8fe2a9' },
    { name: 'Shadow', symbol: '◒', top: '#41345e', sigil: '#d1b1ff', glow: 'rgba(173,121,255,.5)', hue: '#c1a0fa' },
    { name: 'Light', symbol: '☼', top: '#665b38', sigil: '#fff0ac', glow: 'rgba(255,222,125,.5)', hue: '#f6dc91' }
  ];
  const PREFIXES = [
    'Glacial','Silent','Crimson','Drowned','Tempest','Obsidian','Golden','Hollow','Frozen','Shattered',
    'Forgotten','Radiant','Wandering','Ancient','Midnight','Ivory','Stormbound','Cinder','Moonlit','Iron',
    'Whispering','Astral','Emerald','Bleak','Twilight','Silver','Sunken','Scarlet','Eternal','Runic',
    'Crystal','Phantom','Wild','Ashen','Sapphire','Veiled','Thunder','Wicked','Fabled','Winter',
    'Celestial','Bitter','Duskworn','Bright','Feral','Frostbitten','Tidal','Starforged','Grim','Velvet'
  ];
  const SUFFIXES = [
    'Warden','Witness','Sentinel','Oracle','Ranger','Keeper','Monarch','Drifter','Revenant','Guardian',
    'Vanguard','Alchemist','Beast','Knight','Seer','Colossus','Harbinger','Nomad','Specter','Champion',
    'Shade','Titan','Mystic','Outrider','Scholar','Reaper','Archer','Sovereign','Pioneer','Phantom',
    'Envoy','Defender','Herald','Corsair','Mender','Duelist','Enigma','Wayfarer','Monk','Overseer'
  ];
  const ABILITY_TYPES = ['heal','shield','blast','drain','weaken','rally','pierce','restore'];
  const ABILITY_NAMES = {
    heal: ['Mend','Renewal','Lifebloom','Kindle','Rebuild','Warmth','Reprieve','Mercy'],
    shield: ['Aegis','Ward','Bulwark','Safeguard','Barrier','Rampart','Shelter','Fortify'],
    blast: ['Nova','Burst','Riftstrike','Shatter','Detonation','Surge','Comet','Overload'],
    drain: ['Siphon','Leech','Soulpull','Harvest','Bloodless','Draw','Devour','Absorb'],
    weaken: ['Hex','Wither','Dampen','Cripple','Hush','Ruin','Fracture','Enervate'],
    rally: ['Rally','Warcry','Inspire','Overdrive','Momentum','Focus','Ascend','Charge'],
    pierce: ['Piercer','Lance','Truecut','Sundering','Breakline','Skewer','Puncture','Penetrate'],
    restore: ['Rekindle','Second Wind','Resurgence','Afterglow','Reboot','Reawaken','Reform','Revitalize']
  };
  const ELEMENT_MOVES = {
    Frost: ['Icebound','Winterglass','Coldfront','Snowblind','Rime'], Flame: ['Ember','Inferno','Ashen','Wildfire','Cinder'],
    Tide: ['Undertow','Deepcurrent','Riptide','Tidal','Abyssal'], Storm: ['Thunder','Skybreak','Tempest','Static','Cloudburst'],
    Stone: ['Bedrock','Granite','Faultline','Quake','Ironroot'], Verdant: ['Wildgrove','Thorn','Bloom','Overgrowth','Briar'],
    Shadow: ['Nightfall','Umbral','Dusk','Eclipse','Blackveil'], Light: ['Daybreak','Halo','Sunfire','Dawn','Radiant']
  };
  const BOSS_NAMES = ['THE FROSTBOUND','THE ASHEN EMPRESS','THE DEEP CURRENT','THE STORM ARCHON','THE LAST WITNESS'];
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

  function hashNumber(str) {
    let h = 2166136261;
    for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
    return h >>> 0;
  }
  function seededRandom(seedText) {
    let seed = hashNumber(String(seedText)) || 1;
    return () => {
      seed += 0x6D2B79F5;
      let t = seed;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  function randomInt(max) { return Math.floor(Math.random() * max); }
  function localDateKey(date = new Date()) {
    const y = date.getFullYear(); const m = String(date.getMonth() + 1).padStart(2, '0'); const d = String(date.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }
  function formatNumber(n) { return Number(n || 0).toLocaleString('en-US'); }
  function rarityFor(id) {
    const r = (hashNumber(`rarity-${id}`) % 10000) / 100;
    let sum = 0;
    for (const rarity of RARITIES) { sum += rarity.weight; if (r < sum) return rarity; }
    return RARITIES[0];
  }
  function abilityDetails(type, power, cardNo) {
    const amount = Math.round(power);
    const small = Math.max(5, Math.round(power * .62));
    const texts = {
      heal: `Restore ${amount} HP to one of your living allies.`,
      shield: `Give one living ally a ${amount}-point shield.`,
      blast: `Deal ${amount} bonus damage to the weakest enemy.`,
      drain: `Deal ${small} damage and heal this card for ${amount} HP.`,
      weaken: `Deal ${small} damage and weaken an enemy's next strike.`,
      rally: `Boost this card's next attack by ${amount} damage.`,
      pierce: `Deal ${amount} bonus damage that ignores shields.`,
      restore: `Restore ${small} HP to each of your two most injured allies.`
    };
    const labels = ABILITY_NAMES[type];
    const element = ELEMENTS[Math.floor(cardNo / 250) % ELEMENTS.length];
    const move = ELEMENT_MOVES[element.name][Math.floor(cardNo / 8) % ELEMENT_MOVES[element.name].length];
    const label = labels[(cardNo * 3 + Math.floor(cardNo / 11)) % labels.length];
    return { name: `${move} ${label} · ${String(cardNo + 1).padStart(4, '0')}`, text: texts[type], type, power: amount, small };
  }
  function generateCards() {
    const cards = [];
    for (let id = 0; id < 2000; id++) {
      const element = ELEMENTS[Math.floor(id / 250)];
      const rarity = rarityFor(id);
      const tier = rarity.tier;
      const prefix = PREFIXES[Math.floor(id / 40)];
      const suffix = SUFFIXES[id % 40];
      const type = ABILITY_TYPES[(id * 5 + Math.floor(id / 13)) % ABILITY_TYPES.length];
      const attack = 22 + tier * 8 + ((id * 7) % 13);
      const health = 76 + tier * 18 + ((id * 11) % 25);
      const power = 13 + tier * 5 + ((id * 3) % 14);
      cards.push({
        id, code: `CC-${String(id + 1).padStart(4, '0')}`, name: `${prefix} ${suffix}`,
        element, rarity, attack, health, power,
        ability: abilityDetails(type, power, id),
        color: element.hue
      });
    }
    return cards;
  }
  const CARDS = generateCards();
  const cardById = id => CARDS[Number(id)];

  function freshState() {
    return {
      version: 1, coins: 1000, owned: Object.fromEntries(Array.from({ length: 10 }, (_, i) => [i, 1])),
      deckIds: [0,1,2,3,4,5,6,7,8,9], level: 1, lastDaily: '', market: null, battle: null
    };
  }
  function loadState() {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return freshState();
      const parsed = JSON.parse(raw);
      const state = { ...freshState(), ...parsed };
      if (!state.owned || typeof state.owned !== 'object') state.owned = freshState().owned;
      state.owned = Object.fromEntries(Object.entries(state.owned).filter(([id, count]) => Number.isInteger(Number(id)) && Number(id) >= 0 && Number(id) < 2000 && Number(count) > 0));
      state.deckIds = Array.isArray(state.deckIds) ? state.deckIds.filter(id => Number.isInteger(id) && id >= 0 && id < 2000).slice(0, 10) : freshState().deckIds;
      state.level = Math.max(1, Math.min(CAMPAIGN_LENGTH + 1, Number(state.level) || 1));
      state.coins = Math.max(0, Number(state.coins) || 0);
      return state;
    } catch (error) {
      console.warn('Could not read Cold Case save; starting a new case.', error);
      return freshState();
    }
  }
  let state = loadState();
  let toastTimer = null;
  let collectionPage = 0;
  let deckDraft = [...state.deckIds];
  let revealTimer = null;

  function saveState() {
    const safe = { ...state, battle: null };
    try { localStorage.setItem(SAVE_KEY, JSON.stringify(safe)); }
    catch (error) { console.warn('Save failed:', error); }
  }
  function showToast(message) {
    const toast = $('#toast');
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('show'), 2500);
  }
  function ownedCount(id) { return Number(state.owned[id] || 0); }
  function ownedUniqueCount() { return Object.values(state.owned).filter(count => count > 0).length; }
  function currentDeckIsValid(ids = state.deckIds) { return ids.length === 10 && new Set(ids).size === 10 && ids.every(id => ownedCount(id) > 0); }
  function syncHeader() {
    $('#coin-count').textContent = formatNumber(state.coins);
    $('#owned-count').textContent = `${ownedUniqueCount()}/2,000`;
    $('#collection-progress').textContent = `${(ownedUniqueCount() / 20).toFixed(1)}%`;
    $('#daily-date').textContent = `NEXT RESET: ${new Date(new Date().setHours(24,0,0,0)).toLocaleDateString(undefined,{month:'short',day:'numeric'})}`;
    const claimed = state.lastDaily === localDateKey();
    const dailyButton = $('#claim-daily');
    dailyButton.disabled = claimed;
    dailyButton.textContent = claimed ? 'CLAIMED TODAY ✓' : 'CLAIM REWARD';
    dailyButton.classList.toggle('claimed', claimed);
  }
  function addCard(id, count = 1) {
    state.owned[id] = ownedCount(id) + count;
  }
  function rollCardId() {
    const roll = Math.random() * 100;
    let sum = 0; let selected = RARITIES[0];
    for (const rarity of RARITIES) { sum += rarity.weight; if (roll <= sum) { selected = rarity; break; } }
    const candidates = CARDS.filter(card => card.rarity.name === selected.name);
    return candidates[randomInt(candidates.length)].id;
  }

  function cardStyle(card) {
    return `--card-top:${card.element.top};--card-border:${card.element.hue}55;--sigil:${card.element.sigil};--sigil-glow:${card.element.glow};--rarity-color:${card.rarity.color}`;
  }
  function cardMarkup(card, count = 0, options = {}) {
    const locked = options.locked || false;
    const compact = options.compact || false;
    return `<article class="game-card ${locked ? 'locked' : ''} ${compact ? 'compact-card' : ''}" style="${cardStyle(card)}" data-card-id="${card.id}" tabindex="0" aria-label="${card.name}, ${card.rarity.name} ${card.element.name} card">
      <div class="card-topline"><span class="rarity-label">${card.rarity.name.toUpperCase()}</span><span class="card-id">${card.code}</span></div>
      <div class="card-sigil">${card.element.symbol}</div>
      <div class="card-name">${card.name}</div>
      <div class="card-element">${card.element.name.toUpperCase()} ELEMENT</div>
      <div class="card-stats"><span>⚔ ${card.attack} ATK</span><span>♥ ${card.health} HP</span></div>
      <div class="card-ability"><b>${card.ability.name}</b><br>${card.ability.text}</div>
      ${locked ? '<span class="card-count">LOCKED</span>' : count > 1 ? `<span class="card-count">×${count}</span>` : count === 1 ? '<span class="card-owned-tag">OWNED</span>' : ''}
    </article>`;
  }
  function showCardDetails(card, isOwned) {
    showToast(`${card.name} · ${card.rarity.name} ${card.element.name} · ${card.ability.name}: ${card.ability.text}${isOwned ? ` Copies: ${ownedCount(card.id)}.` : ' Not collected yet.'}`);
  }

  function fillFilters() {
    const elementFilter = $('#element-filter');
    ELEMENTS.forEach(element => {
      const option = document.createElement('option'); option.value = element.name; option.textContent = `${element.symbol} ${element.name}`; elementFilter.appendChild(option);
    });
    const rarityFilter = $('#rarity-filter');
    RARITIES.forEach(rarity => {
      const option = document.createElement('option'); option.value = rarity.name; option.textContent = rarity.name; rarityFilter.appendChild(option);
    });
  }
  function renderCollection() {
    const query = $('#card-search').value.trim().toLowerCase();
    const element = $('#element-filter').value;
    const rarity = $('#rarity-filter').value;
    const ownership = $('#ownership-filter').value;
    let filtered = CARDS.filter(card => {
      if (ownership === 'owned' && !ownedCount(card.id)) return false;
      if (element !== 'all' && card.element.name !== element) return false;
      if (rarity !== 'all' && card.rarity.name !== rarity) return false;
      if (query && !`${card.name} ${card.code} ${card.element.name} ${card.rarity.name} ${card.ability.name}`.toLowerCase().includes(query)) return false;
      return true;
    });
    const pages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
    collectionPage = Math.max(0, Math.min(collectionPage, pages - 1));
    const slice = filtered.slice(collectionPage * PAGE_SIZE, (collectionPage + 1) * PAGE_SIZE);
    $('#collection-grid').innerHTML = slice.map(card => cardMarkup(card, ownedCount(card.id), { locked: !ownedCount(card.id) })).join('') || '<div class="empty-slot">NO CARDS MATCH THIS SEARCH.</div>';
    $('#collection-filter-count').textContent = `${filtered.length.toLocaleString()} cards found · ${slice.length} shown`;
    $('#page-label').textContent = `PAGE ${collectionPage + 1} / ${pages}`;
    $('#prev-page').disabled = collectionPage === 0;
    $('#next-page').disabled = collectionPage >= pages - 1;
  }

  function ensureMarket() {
    const today = localDateKey();
    if (state.market && state.market.date === today) return;
    const rand = seededRandom(`cold-case-market-${today}`);
    const used = new Set();
    const offerIds = [];
    while (offerIds.length < 4) {
      const id = Math.floor(rand() * CARDS.length);
      if (!used.has(id)) { used.add(id); offerIds.push(id); }
    }
    const special = rand() < 0.2;
    state.market = { date: today, offers: offerIds, special, packsLeft: special ? 1 + Math.floor(rand() * 5) : 0 };
    saveState();
  }
  function renderMarket() {
    ensureMarket();
    $('#shop-stock-label').textContent = `${state.market.offers.length} OFFERS`;
    $('#market-items').innerHTML = state.market.offers.map(id => {
      const card = cardById(id); const price = card.rarity.price;
      return `<div class="market-item"><div class="market-item-art" style="background:linear-gradient(145deg,${card.element.top},#071b30);color:${card.element.sigil}">${card.element.symbol}</div><div class="market-item-main"><strong>${card.name}</strong><small>${card.rarity.name.toUpperCase()} · ${card.element.name.toUpperCase()}</small></div><button class="market-buy" data-buy-card="${id}">${formatNumber(price)} C</button></div>`;
    }).join('');
    const special = $('#market-special');
    if (state.market.special) {
      const sold = state.market.packsLeft <= 0;
      special.innerHTML = `<div class="special-offer ${sold ? 'sold-out' : ''}"><div><strong>✦ LIMITED 20-CARD CASE</strong><span>${sold ? 'SOLD OUT FOR TODAY' : `${state.market.packsLeft} IN STOCK · 20 CARDS FOR JUST 1,500 COINS`}</span></div><button class="market-buy special-buy" id="buy-special" ${sold ? 'disabled' : ''}>${sold ? 'SOLD OUT' : '1,500 C'}</button></div>`;
    } else {
      special.innerHTML = '<div class="market-intro" style="margin:10px 0 0"><span>✦ No discounted case today. Check back after the market resets.</span></div>';
    }
  }

  function buyCard(id) {
    const card = cardById(id); const price = card.rarity.price;
    if (state.coins < price) { showToast('Not enough coins for this card.'); return; }
    state.coins -= price; addCard(id); saveState(); syncHeader(); renderMarket(); renderCollection(); renderDeckBuilder();
    showToast(`${card.name} added to your collection.`);
  }
  function buySpecialPack() {
    ensureMarket();
    if (!state.market.special || state.market.packsLeft <= 0) { showToast('That limited case is sold out.'); return; }
    purchasePack(20, 1500, true);
  }
  function purchasePack(count = 10, price = PACK_PRICE, limited = false) {
    if (state.coins < price) { showToast(`You need ${formatNumber(price - state.coins)} more coins.`); return; }
    if (limited && (!state.market || state.market.packsLeft <= 0)) { showToast('No limited packs remain.'); return; }
    state.coins -= price;
    if (limited) state.market.packsLeft--;
    const pulled = Array.from({ length: count }, () => rollCardId());
    pulled.forEach(id => addCard(id));
    saveState(); syncHeader(); renderMarket(); renderCollection(); renderDeckBuilder();
    openPackReveal(pulled);
  }
  function openPackReveal(ids) {
    const modal = $('#pack-modal');
    const grid = $('#reveal-grid');
    const done = $('#reveal-done');
    clearInterval(revealTimer);
    grid.innerHTML = ids.map(id => `<div class="reveal-card">${cardMarkup(cardById(id), ownedCount(id), { compact: true })}</div>`).join('');
    $('#pack-opening-subtitle').textContent = `${ids.length} cards are being revealed. Keep an eye out for higher rarities.`;
    $('#reveal-status').textContent = `0 / ${ids.length} REVEALED`;
    $('#reveal-progress-bar').style.width = '0%';
    done.disabled = true;
    modal.hidden = false;
    let index = 0;
    const items = $$('.reveal-card', grid);
    revealTimer = setInterval(() => {
      if (index >= items.length) {
        clearInterval(revealTimer); revealTimer = null;
        $('#reveal-status').textContent = `${ids.length} CARDS ADDED TO YOUR COLLECTION`;
        $('#pack-opening-subtitle').textContent = 'Case opened. Your new cards are ready.';
        done.disabled = false;
        return;
      }
      items[index].classList.add('revealed');
      index++;
      $('#reveal-status').textContent = `${index} / ${ids.length} REVEALED`;
      $('#reveal-progress-bar').style.width = `${(index / ids.length) * 100}%`;
    }, ids.length > 10 ? 105 : 170);
  }
  function closePackReveal() {
    if (revealTimer) { clearInterval(revealTimer); revealTimer = null; }
    $('#pack-modal').hidden = true;
  }

  function setView(view) {
    const isBattle = view === 'battle';
    const collectTarget = ['dashboard', 'collection', 'packs', 'market'].includes(view) ? view : 'dashboard';
    $$('.view').forEach(el => el.classList.toggle('active', el.id === (isBattle ? 'battle-view' : 'collect-view')));
    $$('.collect-panel').forEach(el => el.classList.toggle('active', el.dataset.collectPanel === collectTarget));
    $$('.nav-button').forEach(el => el.classList.toggle('active', el.dataset.view === (isBattle ? 'battle' : collectTarget)));
    window.scrollTo({ top: 0, behavior: 'smooth' });
    if (isBattle) { renderDeckBuilder(); updateCampaignPanel(); if (state.battle) { $('#arena-section').hidden = false; renderArena(); } }
    if (collectTarget === 'collection') renderCollection();
    if (collectTarget === 'market') renderMarket();
  }
  function setBattleTab(tab) {
    $$('.battle-tab').forEach(el => el.classList.toggle('active', el.dataset.battleTab === tab));
    ['campaign','friends','deck'].forEach(name => $(`#${name}-panel`).classList.toggle('active', name === tab));
    if (tab === 'deck') renderDeckBuilder();
    if (tab === 'friends') renderDeckCode();
  }
  function updateCampaignPanel() {
    const complete = state.level > CAMPAIGN_LENGTH;
    const level = Math.min(state.level, CAMPAIGN_LENGTH);
    const boss = level % 5 === 0;
    $('#campaign-level').textContent = complete ? 'COMPLETE' : `LEVEL ${level}`;
    $('#campaign-type').textContent = complete ? 'ALL CASES CRACKED' : boss ? 'BOSS ENCOUNTER' : 'STANDARD ENCOUNTER';
    $('#campaign-progress-text').textContent = `${Math.min(state.level - 1, CAMPAIGN_LENGTH)} / ${CAMPAIGN_LENGTH}`;
    $('#campaign-progress-bar').style.width = `${Math.min(100, ((state.level - 1) / CAMPAIGN_LENGTH) * 100)}%`;
    $('#next-opponent').textContent = boss ? BOSS_NAMES[Math.floor(level / 5) - 1] : ['THE BLUE ARCHIVE','THE LOST PATROL','THE PALE RUNNERS','THE ICEBOUND CIRCLE'][((level - 1) % 4)];
    $('#next-opponent-desc').textContent = boss ? 'A powerful case-holder guards the next milestone.' : 'A team of elemental challengers awaits.';
    $('#next-reward').textContent = `${formatNumber(250 + level * 30 + (boss ? 400 : 0))} C`;
    $('#start-campaign').textContent = complete ? 'REPLAY FINAL CASE ↗' : 'START BATTLE ↗';
  }

  function renderDeckBuilder() {
    const slots = [$('#front-slots'), $('#backup-slots')];
    slots.forEach((container, row) => {
      container.innerHTML = Array.from({ length: 5 }, (_, i) => {
        const id = deckDraft[row * 5 + i];
        if (id === undefined) return `<div class="deck-slot"><span class="empty-slot">${String(row * 5 + i + 1).padStart(2, '0')} · EMPTY SLOT</span></div>`;
        const card = cardById(id);
        return `<div class="deck-slot filled"><div class="slot-sigil" style="color:${card.element.sigil}">${card.element.symbol}</div><div class="slot-info"><strong>${card.name}</strong><small>${card.rarity.name} · ${card.element.name}</small></div></div>`;
      }).join('');
    });
    $('#deck-count').textContent = `${deckDraft.length}/10`;
    const available = CARDS.filter(card => ownedCount(card.id) > 0);
    $('#deck-available-count').textContent = `${available.length} owned cards`;
    $('#deck-card-picker').innerHTML = available.map(card => {
      const selected = deckDraft.includes(card.id);
      return `<button class="picker-card ${selected ? 'selected' : ''}" data-pick-card="${card.id}" style="--picker-color:${card.element.hue}"><span class="picker-sigil" style="color:${card.element.sigil}">${card.element.symbol}</span><span class="picker-info"><strong>${card.name}</strong><small>${card.rarity.name} · ${card.element.name} · ATK ${card.attack}</small></span><span class="picker-mark">${selected ? '✓' : '+'}</span></button>`;
    }).join('');
    $('#save-deck').disabled = !currentDeckIsValid(deckDraft);
    renderDeckCode();
  }
  function makeDeckCode(ids = state.deckIds) {
    const base = btoa(JSON.stringify(ids)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
    return `CC1-${base}`;
  }
  function parseDeckCode(code) {
    try {
      const cleaned = code.trim().replace(/^CC1-/i, '').replace(/-/g, '+').replace(/_/g, '/');
      const padded = cleaned + '='.repeat((4 - cleaned.length % 4) % 4);
      const ids = JSON.parse(atob(padded));
      if (!Array.isArray(ids) || ids.length !== 10 || new Set(ids).size !== 10 || !ids.every(id => Number.isInteger(id) && id >= 0 && id < 2000)) return null;
      return ids;
    } catch (_) { return null; }
  }
  function renderDeckCode() { $('#your-deck-code').textContent = currentDeckIsValid() ? makeDeckCode() : 'BUILD & SAVE A VALID 10-CARD DECK FIRST'; }
  function toggleDeckCard(id) {
    const index = deckDraft.indexOf(id);
    if (index >= 0) deckDraft.splice(index, 1);
    else if (deckDraft.length < 10) deckDraft.push(id);
    else { showToast('Your line-up is full. Remove a card before adding another.'); return; }
    renderDeckBuilder();
  }
  function saveDeck() {
    if (!currentDeckIsValid(deckDraft)) { showToast('Select 10 different owned cards first.'); return; }
    state.deckIds = [...deckDraft]; saveState(); renderDeckBuilder(); showToast('Your ten-card line-up has been saved.');
  }

  function unitFromCard(id, scale = 1) {
    const card = cardById(id);
    return { cardId: id, hp: Math.round(card.health * scale), maxHp: Math.round(card.health * scale), shield: 0, attack: Math.round(card.attack * scale), power: Math.round(card.power * scale), abilityUsed: false, weakened: false, bonusDamage: 0 };
  }
  function activeAlive(team) { return team.active.some(unit => unit && unit.hp > 0); }
  function allAlive(team) { return [...team.active, ...team.backup].some(unit => unit && unit.hp > 0); }
  function findActiveIndex(team, start = 0) {
    for (let i = start; i < team.active.length; i++) if (team.active[i] && team.active[i].hp > 0) return i;
    return team.active.findIndex(unit => unit && unit.hp > 0);
  }
  function makeTeam(name, ids, scale = 1) {
    return { name, active: ids.slice(0, 5).map(id => unitFromCard(id, scale)), backup: ids.slice(5, 10).map(id => unitFromCard(id, scale)) };
  }
  function randomEnemyIds() {
    const ids = []; const used = new Set();
    while (ids.length < 10) { const id = randomInt(CARDS.length); if (!used.has(id)) { used.add(id); ids.push(id); } }
    return ids;
  }
  function startCampaignBattle() {
    if (!currentDeckIsValid()) { setBattleTab('deck'); showToast('Build and save a ten-card line-up before battling.'); return; }
    const level = Math.min(state.level, CAMPAIGN_LENGTH);
    const boss = level % 5 === 0;
    const scale = 1 + (level - 1) * .026 + (boss ? .12 : 0);
    const enemyName = boss ? BOSS_NAMES[Math.floor(level / 5) - 1] : ['THE BLUE ARCHIVE','THE LOST PATROL','THE PALE RUNNERS','THE ICEBOUND CIRCLE'][(level - 1) % 4];
    const battle = {
      mode: 'campaign', level, boss, title: enemyName, currentSide: 0,
      teams: [makeTeam('YOU', state.deckIds), makeTeam(enemyName, randomEnemyIds(), scale)],
      selectedAttacker: findActiveIndex(makeTeam('temp', state.deckIds)), selectedTarget: 0, selectedBackup: null,
      log: [`CASE ${String(level).padStart(2,'0')} OPENED. ${enemyName} HAS ENTERED THE ARENA.`], ended: false, result: null
    };
    state.battle = battle;
    openArena();
  }
  function startFriendBattle() {
    if (!currentDeckIsValid()) { setBattleTab('deck'); showToast('Build and save your ten-card line-up first.'); return; }
    const input = $('#friend-deck-code').value.trim();
    const imported = input ? parseDeckCode(input) : null;
    if (input && !imported) { showToast('That deck code is not valid. Check it and try again.'); return; }
    const usedDeck = imported || shuffle([...state.deckIds]);
    const friendName = ($('#friend-name').value.trim() || 'Player 2').slice(0,18);
    state.battle = {
      mode: 'friend', level: 0, boss: false, title: 'FRIEND DUEL', currentSide: 0,
      teams: [makeTeam('PLAYER 1', state.deckIds), makeTeam(friendName.toUpperCase(), usedDeck)],
      selectedAttacker: 0, selectedTarget: 0, selectedBackup: null,
      log: [`FRIEND DUEL CREATED. PLAYER 1 VS ${friendName.toUpperCase()}.`, imported ? 'PLAYER 2 DECK CODE LOADED.' : 'PRACTICE LINE-UP DEALT TO PLAYER 2.'], ended: false, result: null
    };
    openArena();
  }
  function shuffle(array) {
    const copy = [...array];
    for (let i = copy.length - 1; i > 0; i--) { const j = randomInt(i + 1); [copy[i], copy[j]] = [copy[j], copy[i]]; }
    return copy;
  }
  function openArena() {
    $('#arena-section').hidden = false;
    $('#arena-title').textContent = state.battle.title;
    $('#battle-end').hidden = true;
    renderArena();
    $('#arena-section').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
  function addLog(text) {
    const battle = state.battle;
    battle.log.unshift(text);
    if (battle.log.length > 12) battle.log.length = 12;
  }
  function replaceKnockedOut(team, label) {
    for (let i = 0; i < team.active.length; i++) {
      if (team.active[i] && team.active[i].hp <= 0 && team.backup.length) {
        const replacement = team.backup.shift();
        team.active[i] = replacement;
        const card = cardById(replacement.cardId);
        addLog(`${label}: ${card.name} joins the front line from backup.`);
      }
    }
  }
  function livingActive(team) { return team.active.map((unit, index) => ({ unit, index })).filter(entry => entry.unit && entry.unit.hp > 0); }
  function weakestActive(team) {
    return livingActive(team).sort((a,b) => (a.unit.hp / a.unit.maxHp) - (b.unit.hp / b.unit.maxHp))[0];
  }
  function applyDamage(target, amount, ignoreShield = false) {
    let damage = Math.max(1, Math.round(amount));
    if (!ignoreShield && target.shield > 0) {
      const blocked = Math.min(target.shield, damage);
      target.shield -= blocked; damage -= blocked;
    }
    target.hp = Math.max(0, target.hp - damage);
    return damage;
  }
  function attackUnit(attacker, target, attackerName, targetName, isEnemy = false) {
    const card = cardById(attacker.cardId);
    let damage = Math.max(5, Math.round(attacker.attack * (.82 + Math.random() * .36) + attacker.bonusDamage));
    if (attacker.weakened) { damage = Math.round(damage * .72); attacker.weakened = false; }
    attacker.bonusDamage = 0;
    const dealt = applyDamage(target, damage, card.ability.type === 'pierce');
    const targetCard = cardById(target.cardId);
    addLog(`${attackerName}'s ${card.name} hits ${targetName}'s ${targetCard.name} for ${dealt} damage${target.hp <= 0 ? ' — knocked out!' : '.'}`);
    return dealt;
  }
  function useAbility(battle, side, attackerIndex) {
    const team = battle.teams[side]; const opponents = battle.teams[1 - side];
    const attacker = team.active[attackerIndex];
    if (!attacker || attacker.hp <= 0 || attacker.abilityUsed) return false;
    const card = cardById(attacker.cardId); const ability = card.ability; const type = ability.type; const power = Math.max(8, Math.round(attacker.power));
    attacker.abilityUsed = true;
    const allyEntries = livingActive(team);
    const enemyTarget = weakestActive(opponents);
    const allyTarget = [...allyEntries].sort((a,b) => (a.unit.hp/a.unit.maxHp) - (b.unit.hp/b.unit.maxHp)).find(entry => entry.unit.hp < entry.unit.maxHp) || allyEntries.find(entry => entry.index !== attackerIndex) || allyEntries[0];
    if (type === 'heal') {
      if (!allyTarget || allyTarget.unit.hp >= allyTarget.unit.maxHp) { addLog(`${card.name}'s ${ability.name} found no ally who needed healing.`); return true; }
      const amount = Math.min(power, allyTarget.unit.maxHp - allyTarget.unit.hp); allyTarget.unit.hp += amount;
      addLog(`${card.name} uses ${ability.name}: ${cardById(allyTarget.unit.cardId).name} heals ${amount} HP.`);
    } else if (type === 'shield') {
      const target = allyTarget || { unit: attacker, index: attackerIndex };
      target.unit.shield += power;
      addLog(`${card.name} uses ${ability.name}: ${cardById(target.unit.cardId).name} gains ${power} shield.`);
    } else if (type === 'blast') {
      if (!enemyTarget) return false;
      const dealt = applyDamage(enemyTarget.unit, power, false);
      addLog(`${card.name} unleashes ${ability.name} on ${cardById(enemyTarget.unit.cardId).name} for ${dealt} damage.`);
    } else if (type === 'drain') {
      if (!enemyTarget) return false;
      const dealt = applyDamage(enemyTarget.unit, Math.max(5, Math.round(power * .62)), false);
      const healing = Math.min(power, attacker.maxHp - attacker.hp); attacker.hp += healing;
      addLog(`${card.name} uses ${ability.name}: ${dealt} damage dealt and ${healing} HP restored.`);
    } else if (type === 'weaken') {
      if (!enemyTarget) return false;
      const dealt = applyDamage(enemyTarget.unit, Math.max(5, Math.round(power * .62)), false);
      enemyTarget.unit.weakened = true;
      addLog(`${card.name} uses ${ability.name}: ${dealt} damage and the target's next strike is weakened.`);
    } else if (type === 'rally') {
      attacker.bonusDamage += power;
      addLog(`${card.name} uses ${ability.name}: its next attack gains ${power} bonus damage.`);
    } else if (type === 'pierce') {
      if (!enemyTarget) return false;
      const dealt = applyDamage(enemyTarget.unit, power, true);
      addLog(`${card.name} uses ${ability.name}: pierces through shields for ${dealt} damage.`);
    } else if (type === 'restore') {
      const injured = [...allyEntries].sort((a,b) => (a.unit.hp/a.unit.maxHp) - (b.unit.hp/b.unit.maxHp)).slice(0,2);
      let healed = 0;
      injured.forEach(entry => { const amount = Math.min(Math.max(5, Math.round(power * .62)), entry.unit.maxHp - entry.unit.hp); entry.unit.hp += amount; healed += amount; });
      addLog(`${card.name} uses ${ability.name}: restored ${healed} total HP across the team.`);
    }
    replaceKnockedOut(opponents, opponents.name);
    return true;
  }
  function checkBattleEnd() {
    const battle = state.battle;
    if (!battle || battle.ended) return true;
    const aAlive = allAlive(battle.teams[0]); const bAlive = allAlive(battle.teams[1]);
    if (!aAlive || !bAlive) {
      const winner = aAlive ? 0 : 1;
      battle.ended = true; battle.result = winner;
      if (battle.mode === 'campaign') {
        const won = winner === 0;
        if (won) {
          const reward = 250 + battle.level * 30 + (battle.boss ? 400 : 0);
          state.coins += reward;
          state.level = Math.min(CAMPAIGN_LENGTH + 1, state.level + 1);
          addLog(`CASE CLOSED. YOU EARNED ${formatNumber(reward)} COINS.`);
          saveState(); syncHeader(); updateCampaignPanel();
          $('#battle-end-title').textContent = 'CASE CLOSED';
          $('#battle-end-text').textContent = `Victory. ${formatNumber(reward)} coins added to your balance. ${state.level > CAMPAIGN_LENGTH ? 'You have cleared all 25 campaign cases.' : `Case ${state.level} is now unlocked.`}`;
        } else {
          addLog('CASE FAILED. YOUR TEAM HAS BEEN DEFEATED.');
          $('#battle-end-title').textContent = 'CASE FAILED';
          $('#battle-end-text').textContent = 'Your team was defeated. Adjust your line-up and try this case again.';
        }
      } else {
        $('#battle-end-title').textContent = winner === 0 ? 'PLAYER 1 WINS' : `${battle.teams[1].name} WINS`;
        $('#battle-end-text').textContent = 'Friend duel complete. Start another round to settle the score.';
      }
      $('#battle-end').hidden = false;
      $('#attack-action').disabled = true; $('#ability-action').disabled = true; $('#swap-action').disabled = true;
      return true;
    }
    return false;
  }
  function executePlayerAction(kind) {
    const battle = state.battle;
    if (!battle || battle.ended) return;
    const side = battle.currentSide; const team = battle.teams[side]; const opponents = battle.teams[1 - side];
    const attacker = team.active[battle.selectedAttacker];
    if (!attacker || attacker.hp <= 0) { showToast('Choose a living card from your front line.'); return; }
    if (kind === 'attack') {
      const target = opponents.active[battle.selectedTarget];
      if (!target || target.hp <= 0) { showToast('Choose a living opponent to attack.'); return; }
      attackUnit(attacker, target, team.name, opponents.name);
      replaceKnockedOut(opponents, opponents.name);
    } else if (kind === 'ability') {
      if (attacker.abilityUsed) { showToast('This card has already used its ability this battle.'); return; }
      useAbility(battle, side, battle.selectedAttacker);
    }
    if (checkBattleEnd()) { renderArena(); return; }
    if (battle.mode === 'campaign') {
      enemyTurn();
      if (!checkBattleEnd()) battle.currentSide = 0;
    } else {
      battle.currentSide = 1 - battle.currentSide;
      battle.selectedAttacker = findActiveIndex(battle.teams[battle.currentSide]);
      battle.selectedTarget = findActiveIndex(battle.teams[1 - battle.currentSide]);
      battle.selectedBackup = null;
      addLog(`${battle.teams[battle.currentSide].name.toUpperCase()}'S TURN.`);
    }
    renderArena();
  }
  function enemyTurn() {
    const battle = state.battle;
    const enemy = battle.teams[1]; const player = battle.teams[0];
    const attackers = livingActive(enemy); const targets = livingActive(player);
    if (!attackers.length || !targets.length) return;
    const attacker = attackers[randomInt(attackers.length)];
    const target = targets[randomInt(targets.length)];
    attackUnit(attacker.unit, target.unit, enemy.name, player.name, true);
    replaceKnockedOut(player, player.name);
    // Bosses occasionally use a signature ability for extra pressure.
    if (battle.boss && !attacker.unit.abilityUsed && Math.random() < .2 && allAlive(enemy)) {
      useAbility(battle, 1, attacker.index);
      replaceKnockedOut(player, player.name);
    }
  }
  function swapBackup() {
    const battle = state.battle;
    if (!battle || battle.ended) return;
    const team = battle.teams[battle.currentSide];
    const backupIndex = battle.selectedBackup;
    if (backupIndex === null || !team.backup[backupIndex] || team.backup[backupIndex].hp <= 0) { showToast('Choose a living backup card first.'); return; }
    const activeIndex = battle.selectedAttacker;
    if (activeIndex === null || activeIndex < 0 || activeIndex >= team.active.length || !team.active[activeIndex] || team.active[activeIndex].hp <= 0) { showToast('Choose the active card you want to swap out.'); return; }
    const outgoing = team.active[activeIndex];
    const incoming = team.backup[backupIndex];
    team.active[activeIndex] = incoming;
    team.backup[backupIndex] = outgoing;
    addLog(`${team.name}: ${cardById(incoming.cardId).name} swaps into the front line.`);
    if (battle.mode === 'campaign') { enemyTurn(); checkBattleEnd(); }
    else { battle.currentSide = 1 - battle.currentSide; battle.selectedAttacker = findActiveIndex(battle.teams[battle.currentSide]); battle.selectedTarget = findActiveIndex(battle.teams[1 - battle.currentSide]); addLog(`${battle.teams[battle.currentSide].name.toUpperCase()}'S TURN.`); }
    battle.selectedBackup = null;
    renderArena();
  }
  function renderArenaCard(unit, index, selected, target, clickable, sideType) {
    if (!unit) return '<div class="arena-card down"><div class="arena-sigil">—</div><strong>EMPTY</strong></div>';
    const card = cardById(unit.cardId);
    const down = unit.hp <= 0;
    const hpPct = Math.max(0, Math.min(100, unit.hp / unit.maxHp * 100));
    const classes = ['arena-card', selected ? 'selected' : '', target ? 'targeted' : '', down ? 'down' : ''].filter(Boolean).join(' ');
    return `<button class="${classes}" data-arena-card="${index}" data-side-type="${sideType}" ${down || !clickable ? 'disabled' : ''} style="--sigil:${card.element.sigil}">
      <span class="arena-sigil">${card.element.symbol}</span><strong>${card.name}</strong><small>${card.rarity.name.toUpperCase()} · ${card.element.name.toUpperCase()}</small>
      <div class="hp-row"><i style="width:${hpPct}%"></i></div><div class="hp-text"><span>${Math.max(0,unit.hp)} / ${unit.maxHp} HP</span><span>⚔ ${unit.attack}</span></div>
      ${unit.shield > 0 ? `<div class="shield-label">✧ ${unit.shield} SHIELD</div>` : ''}${unit.abilityUsed ? '<div class="shield-label">ABILITY USED</div>' : ''}
    </button>`;
  }
  function renderArena() {
    const battle = state.battle;
    if (!battle) return;
    const currentSide = battle.currentSide;
    const friendly = battle.teams[currentSide]; const opponent = battle.teams[1-currentSide];
    const isFriend = battle.mode === 'friend';
    $('#arena-title').textContent = battle.title;
    $('#turn-badge').textContent = isFriend ? `${friendly.name.toUpperCase()}'S TURN` : 'YOUR TURN';
    $('#enemy-team-label').textContent = opponent.name.toUpperCase();
    $('#friendly-side-label').textContent = `${friendly.name.toUpperCase()} FRONT LINE`;
    $('#opponent-side-label').textContent = `${opponent.name.toUpperCase()} FRONT LINE`;
    $('#player-team-count').textContent = `${livingActive(friendly).length} ACTIVE`;
    $('#enemy-team-count').textContent = `${livingActive(opponent).length} ACTIVE`;
    $('#friendly-team').innerHTML = friendly.active.map((unit, index) => renderArenaCard(unit, index, index === battle.selectedAttacker, false, true, 'friendly')).join('');
    $('#opponent-team').innerHTML = opponent.active.map((unit, index) => renderArenaCard(unit, index, false, index === battle.selectedTarget, true, 'opponent')).join('');
    $('#friendly-backup').innerHTML = friendly.backup.map((unit, index) => {
      const card = cardById(unit.cardId); const disabled = unit.hp <= 0;
      return `<button class="backup-card ${battle.selectedBackup === index ? 'selected' : ''}" data-backup-index="${index}" ${disabled ? 'disabled' : ''}><span style="color:${card.element.sigil}">${card.element.symbol}</span><span style="min-width:0"><strong>${card.name}</strong><small>${unit.hp}/${unit.maxHp} HP ${disabled ? '· DOWN' : ''}</small></span></button>`;
    }).join('') || '<span class="empty-slot">NO BACKUP CARDS REMAIN.</span>';
    const selectedUnit = friendly.active[battle.selectedAttacker];
    const canAct = !battle.ended && selectedUnit && selectedUnit.hp > 0;
    $('#attack-action').disabled = !canAct || !opponent.active[battle.selectedTarget] || opponent.active[battle.selectedTarget].hp <= 0;
    $('#ability-action').disabled = !canAct || selectedUnit.abilityUsed;
    $('#swap-action').disabled = !canAct || battle.selectedBackup === null || !friendly.backup[battle.selectedBackup] || friendly.backup[battle.selectedBackup].hp <= 0;
    if (selectedUnit) {
      const card = cardById(selectedUnit.cardId);
      const target = card.ability.type === 'heal' || card.ability.type === 'shield' || card.ability.type === 'restore' ? 'lowest-health ally' : 'weakest enemy';
      $('#selection-hint').textContent = `${card.name}: ${card.ability.name} — ${card.ability.text} Ability target: ${target}.`;
    } else $('#selection-hint').textContent = 'Select a living active card to act.';
    $('#battle-log').innerHTML = battle.log.map(line => `<div class="log-line">${line}</div>`).join('');
    $('#battle-end').hidden = !battle.ended;
    if (battle.ended) {
      $('#attack-action').disabled = true; $('#ability-action').disabled = true; $('#swap-action').disabled = true;
    }
  }

  function bindEvents() {
    $$('.nav-button').forEach(button => button.addEventListener('click', () => setView(button.dataset.view)));
    $('.brand').addEventListener('click', event => { event.preventDefault(); setView('dashboard'); });
    $('#hero-open-pack').addEventListener('click', () => purchasePack(10, PACK_PRICE));
    $('#hero-view-cards').addEventListener('click', () => setView('collection'));
    $$('[data-go-view]').forEach(button => button.addEventListener('click', () => setView(button.dataset.goView)));
    $('#claim-daily').addEventListener('click', () => {
      if (state.lastDaily === localDateKey()) return;
      state.coins += 1000; state.lastDaily = localDateKey(); saveState(); syncHeader(); showToast('Daily allowance collected: +1,000 coins.');
    });
    $('#buy-pack').addEventListener('click', () => purchasePack(10, PACK_PRICE));
    $('#market-items').addEventListener('click', event => {
      const button = event.target.closest('[data-buy-card]'); if (button) buyCard(Number(button.dataset.buyCard));
    });
    $('#market-special').addEventListener('click', event => { if (event.target.closest('#buy-special')) buySpecialPack(); });
    $('#close-pack-modal').addEventListener('click', closePackReveal);
    $('#reveal-done').addEventListener('click', closePackReveal);
    $('#pack-modal').addEventListener('click', event => { if (event.target.id === 'pack-modal' && !$('#reveal-done').disabled) closePackReveal(); });
    ['card-search','element-filter','rarity-filter','ownership-filter'].forEach(id => $(`#${id}`).addEventListener('input', () => { collectionPage = 0; renderCollection(); }));
    $('#collection-grid').addEventListener('click', event => { const cardEl = event.target.closest('[data-card-id]'); if (cardEl) showCardDetails(cardById(Number(cardEl.dataset.cardId)), ownedCount(Number(cardEl.dataset.cardId)) > 0); });
    $('#prev-page').addEventListener('click', () => { collectionPage--; renderCollection(); });
    $('#next-page').addEventListener('click', () => { collectionPage++; renderCollection(); });
    $$('.battle-tab').forEach(button => button.addEventListener('click', () => setBattleTab(button.dataset.battleTab)));
    $('#start-campaign').addEventListener('click', startCampaignBattle);
    $('#start-friend').addEventListener('click', startFriendBattle);
    $('#deck-card-picker').addEventListener('click', event => { const button = event.target.closest('[data-pick-card]'); if (button) toggleDeckCard(Number(button.dataset.pickCard)); });
    $('#save-deck').addEventListener('click', saveDeck);
    $('#copy-deck-code').addEventListener('click', async () => {
      if (!currentDeckIsValid()) { showToast('Save a valid ten-card line-up first.'); return; }
      const code = makeDeckCode();
      try { await navigator.clipboard.writeText(code); showToast('Deck code copied. Send it to your friend.'); }
      catch (_) { window.prompt('Copy your Cold Case deck code:', code); }
    });
    $('#friendly-team').addEventListener('click', event => {
      const button = event.target.closest('[data-arena-card]'); if (!button || !state.battle || state.battle.ended) return;
      state.battle.selectedAttacker = Number(button.dataset.arenaCard); renderArena();
    });
    $('#opponent-team').addEventListener('click', event => {
      const button = event.target.closest('[data-arena-card]'); if (!button || !state.battle || state.battle.ended) return;
      state.battle.selectedTarget = Number(button.dataset.arenaCard); renderArena();
    });
    $('#friendly-backup').addEventListener('click', event => {
      const button = event.target.closest('[data-backup-index]'); if (!button || !state.battle || state.battle.ended) return;
      state.battle.selectedBackup = Number(button.dataset.backupIndex); renderArena();
    });
    $('#attack-action').addEventListener('click', () => executePlayerAction('attack'));
    $('#ability-action').addEventListener('click', () => executePlayerAction('ability'));
    $('#swap-action').addEventListener('click', swapBackup);
    $('#battle-end-button').addEventListener('click', () => {
      const mode = state.battle?.mode; state.battle = null; $('#arena-section').hidden = true;
      if (mode === 'friend') setBattleTab('friends'); else setBattleTab('campaign');
    });
  }

  function init() {
    fillFilters(); ensureMarket(); bindEvents();
    // A new player starts with 1,000 welcome coins and ten starter cards.
    syncHeader(); renderMarket(); renderCollection(); renderDeckBuilder(); updateCampaignPanel();
    if (state.lastDaily !== localDateKey()) $('#claim-daily').textContent = 'CLAIM REWARD';
  }
  init();
})();
