COLD CASE — THE ELEMENTAL CARD GAME
===================================

OPENING THE GAME
1. Extract the ZIP folder.
2. Open index.html in Chrome, Edge, Firefox or Safari.
3. The game saves automatically in that browser using local storage.

MAIN NAVIGATION
- Home: overview, daily coin claim and quick-launch buttons.
- Collection: browse owned cards or switch to the full 2,000-card compendium.
- Packs: buy and open ten-card packs with the animated reveal.
- Market: browse fixed-price card offers and the limited-stock special pack.
- Battle: enter the campaign, set up a friend duel, or build your ten-card deck.

HOW TO PLAY
1. You begin with 1,000 welcome coins and 10 starter cards.
2. Claim 1,000 daily coins from Home.
3. Open Packs to buy a ten-card pack, or visit Market for individual cards and limited stock offers.
4. In Collection, use search and filters to find particular cards. Choose Full compendium to browse all 2,000 cards.
5. In Battle > Deck Builder, select 10 different owned cards and save the line-up. The first five are your active team; the next five are your backup.
6. In Campaign, fight levels and bosses to earn coins. Each fifth level is a boss encounter.
7. In Friend Duel, play pass-and-play on one device. Copy your deck code to share your line-up with a friend.

IMPORTANT NOTES
- The 2,000-card catalogue is generated from original names, eight elements, six rarity tiers and individual ability values. Card faces are drawn by the game's interface rather than downloaded image files.
- Daily rewards and the rotating market use the device's local calendar date.
- Friend battles are pass-and-play on one device. Live online multiplayer requires a multiplayer server and is not included.
- Your save belongs to the browser/device where you play. Clearing browser site data will clear the save.

FILES
- index.html  Main game page and navigation
- style.css   Blue/ice visual design and responsive layout
- game.js     Card catalogue, economy, shops, deck building and battle logic
- README.txt  This guide
